import requests
import json
from config.config import Config
import random

def get_weather(city):
    if not Config.WEATHER_API_KEY:
        # Mock
        return {
            'temp': random.randint(10, 30),
            'description': random.choice(['Clear', 'Rain', 'Cloudy']),
            'wind': random.randint(5, 20)
        }
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={Config.WEATHER_API_KEY}&units=metric"
    try:
        resp = requests.get(url)
        data = resp.json()
        return {
            'temp': data['main']['temp'],
            'description': data['weather'][0]['description'],
            'wind': data['wind']['speed']
        }
    except:
        return None

def get_traffic(city):
    # Mock for now
    return random.choice(['Low', 'Medium', 'High'])

def predict_hot_zones(city, current_time):
    # Mock hot zones
    zones = [
        {'name': 'Downtown', 'lat': 40.7128, 'lon': -74.0060, 'score': 95, 'est_earnings': 35},
        {'name': 'Airport', 'lat': 40.6413, 'lon': -73.7781, 'score': 85, 'est_earnings': 28},
        {'name': 'Suburbs', 'lat': 40.85, 'lon': -73.95, 'score': 70, 'est_earnings': 22},
    ]
    # Filter based on time, weather etc. in future
    return zones
