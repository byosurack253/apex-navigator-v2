import sqlite3
import pandas as pd
from datetime import datetime

def init_db():
    conn = sqlite3.connect('dash_data.db')
    conn.execute('''
        CREATE TABLE IF NOT EXISTS shifts (
            id INTEGER PRIMARY KEY,
            date TEXT,
            hours REAL,
            earnings REAL,
            zone TEXT,
            notes TEXT
        )
    ''')
    conn.close()

def log_shift(hours, earnings, zone, notes=""):
    conn = sqlite3.connect('dash_data.db')
    date = datetime.now().strftime('%Y-%m-%d')
    conn.execute("INSERT INTO shifts (date, hours, earnings, zone, notes) VALUES (?, ?, ?, ?, ?)",
                 (date, hours, earnings, zone, notes))
    conn.commit()
    conn.close()

def get_stats():
    conn = sqlite3.connect('dash_data.db')
    df = pd.read_sql("SELECT * FROM shifts", conn)
    conn.close()
    return df
