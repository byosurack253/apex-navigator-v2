import streamlit as st
import pandas as pd
import folium
from streamlit_folium import st_folium
from config.config import Config
from utils.api_utils import get_weather, get_traffic, predict_hot_zones
from utils.earnings import calculate_potential_earnings
from utils.crowdsource import get_crowd_data
from data.db import init_db, log_shift, get_stats
import datetime

st.set_page_config(page_title="DashOptimizer - GodMode", layout="wide")

st.title("🚀 DashOptimizer - Maximize Your DoorDash Earnings")

# Sidebar
st.sidebar.header("Settings")
city = st.sidebar.text_input("City", Config.DEFAULT_CITY)
current_time = datetime.datetime.now()

init_db()  # Ensure DB ready

# Main dashboard
col1, col2 = st.columns(2)

with col1:
    st.subheader("Current Conditions")
    weather = get_weather(city)
    if weather:
        st.write(f"Temp: {weather['temp']}°C, Condition: {weather['description']}")
        st.write(f"Wind: {weather['wind']} km/h")

    traffic = get_traffic(city)
    if traffic:
        st.write(f"Traffic Level: {traffic}")

    crowd = get_crowd_data(city)
    st.write("Crowd Insights:", crowd)

with col2:
    st.subheader("Hot Zones")
    zones = predict_hot_zones(city, current_time)
    st.dataframe(pd.DataFrame(zones))

# Map
st.subheader("Live Map")
m = folium.Map(location=[40.7128, -74.0060], zoom_start=12)
for zone in zones:
    folium.Marker([zone['lat'], zone['lon']], popup=zone['name']).add_to(m)
st_folium(m, width=700, height=500)

# Earnings predictor
st.subheader("Earnings Predictor")
hours = st.slider("Hours dashing", 1, 10, 4)
potential = calculate_potential_earnings(hours, zones)
st.metric("Estimated Earnings", f"${potential:.2f}")

st.button("Start Shift Alert")

# Analytics
st.subheader("Your Stats")
stats = get_stats()
if not stats.empty:
    st.dataframe(stats)
    st.metric("Total Earnings", f"${stats['earnings'].sum():.2f}")
else:
    st.write("No shifts logged yet. Log some to see stats!")
