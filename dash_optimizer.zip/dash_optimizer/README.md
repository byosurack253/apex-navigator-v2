# DashOptimizer - GodMode Edition

Ultimate tool for DoorDash drivers to maximize earnings.

## Features
- Real-time weather, traffic integration
- AI-like hot zone prediction
- Earnings forecasting
- Shift logging and analytics
- Interactive map

## Setup
1. pip install -r requirements.txt
2. Copy .env.example to .env and add API keys
3. streamlit run app/main.py

## Future Enhancements
- ML model for predictions
- Crowd-sourced data via backend
- Push notifications
- Multi-city support
- Route optimizer with Google OR-Tools

Made to print money for dashers.
