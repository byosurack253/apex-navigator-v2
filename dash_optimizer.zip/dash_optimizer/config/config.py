import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    WEATHER_API_KEY = os.getenv('OPENWEATHER_API_KEY')
    GOOGLE_MAPS_API_KEY = os.getenv('GOOGLE_MAPS_API_KEY')
    # Add more APIs
    DEFAULT_CITY = "New York"
    HOT_ZONE_RADIUS = 5  # km
    EARNINGS_PER_HOUR_TARGET = 25
