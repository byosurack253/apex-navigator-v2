def calculate_potential_earnings(hours, zones):
    if not zones:
        return hours * 20
    avg = sum(z['est_earnings'] for z in zones) / len(zones)
    return hours * avg * 0.9  # 10% buffer
