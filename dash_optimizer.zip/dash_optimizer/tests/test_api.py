import pytest
from utils.api_utils import get_weather

def test_get_weather():
    data = get_weather("TestCity")
    assert data is not None
