# Mock crowd-sourced data from other dashers
def get_crowd_data(city):
    return {
        'busy_areas': ['Downtown', 'Mall'],
        'tips_report': {'Downtown': 'High tips today'},
        'wait_times': {'Airport': 15}
    }
